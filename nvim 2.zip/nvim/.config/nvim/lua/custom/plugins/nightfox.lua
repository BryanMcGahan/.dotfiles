return {
	"EdenEast/nightfox.nvim",
	opts = {
		options = {
			dim_inactive = false,
			transparent = true,
			terminal_colors = true,
			styles = {
				comments = "NONE",
				functions = "NONE",
			},
		},
	},
}
