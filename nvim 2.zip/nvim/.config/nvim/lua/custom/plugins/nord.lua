return {
	"arcticicestudio/nord-vim",
}
