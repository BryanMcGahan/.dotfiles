vim.cmd("colorscheme kanagawa")
