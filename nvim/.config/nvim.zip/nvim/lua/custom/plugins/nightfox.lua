return {
	"EdenEast/nightfox.nvim",
	opts = {
		options = {
			dim_inactive = true,
			transparent = false,
			terminal_colors = true,
			styles = {
				comments = "italic",
				functions = "bold",
			},
		},
	},
}
