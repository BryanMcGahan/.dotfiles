return {
	"morhetz/gruvbox",
	config = function()
        vim.g.gruvbox_contrast_dark = "hard"
        vim.g.gruvbox_invert_selection = 0
	end,
}
