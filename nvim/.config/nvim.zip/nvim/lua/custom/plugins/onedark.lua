return {
	"navarasu/onedark.nvim",
	opts = {
        style = "dark",
		lualine = {
			transparent = true,
		},
	},
}
